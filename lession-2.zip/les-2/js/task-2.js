alert(null || 2 || undefined); // 2, т.к., один из агрументов истина (2)
alert(1 && null && 2); // null, т.к., один из агрументов (null) - false