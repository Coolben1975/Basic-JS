let randomInt = Math.floor(Math.random() * 15) + 1; //случайное число (0-15)
switch (randomInt) {
    case randomInt:
        while (randomInt !== 16) {
            alert(randomInt);
            randomInt++;
        }
        break;
}