alert(0 == null);
alert(0 === null);
// в обоих случаях - false, т.к., null - это ничего 