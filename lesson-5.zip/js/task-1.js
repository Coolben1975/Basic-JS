'use strict';
let cardColor = 'white';
let arr = [{ cost: 100, name: 'пояс' }, { cost: 200, name: 'кроссовки' }, { cost: 300, name: 'кепка' },
{ cost: 400, name: 'джинсы' }, { cost: 500, name: 'куртка' }, { cost: 6, name: 'брелок' }];
let countBasketSum = 0;
const root = document.querySelector('#root');

for (let i = 0; i < arr.length; i++) {
    if (i % 2 == 0) {
        cardColor = 'black';
    } else {
        cardColor = 'white';
    }

    const div = document.createElement('div');
    div.className = 'card';
    div.classList.add(cardColor);
    div.innerText = arr[i].name + ': ' + arr[i].cost + ' руб.';
    root.append(div);
    countBasketSum += arr[i].cost; //ссумируем корзину
}

const div = document.createElement('div');
div.innerText = 'В корзине: ' + arr.length + ' товаров на сумму ' + countBasketSum + ' рублей';
root.append(div);